import math
print("FLAG =", math.gcd(66528, 52920))
